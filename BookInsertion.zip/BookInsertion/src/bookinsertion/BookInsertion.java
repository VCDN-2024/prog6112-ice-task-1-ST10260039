 //Title: Insertion Sort Algorithm
       //Author:Rajat Mishra
       //Date: 7 August 2024
       //Availabilty:geeksforgeeks.org/insertion-sort-algorithm/ 
package bookinsertion;

import java.util.Arrays;
import javax.swing.JOptionPane;


public class BookInsertion {
    public static void InsertionSort(String[] BookTitles) {
//        
        for (int i = 1; i < BookTitles.length; ++i) {
          
            //string to store boooktitles as they being entered or pre-entered
            String key = BookTitles[i];
             //new count variable to temporarily store variables
            int j = i - 1;
             //code that swaps the book titles in ascending order             
            while (j >= 0 && BookTitles[j].compareTo(key)>0) {
                BookTitles[j + 1] = BookTitles[j];
                j = j - 1;
            }
            BookTitles[j + 1] = key;
        }
       
    }
     public static void InsertionSortDec(String[] BookTitles) {
//        
          for (int i = 1; i < BookTitles.length; ++i) {
          
            //string to store boooktitles as they being entered or pre-entered
            String key = BookTitles[i];
            //new count variable to temporarily store variables
            int j = i - 1;
                 //code that swaps the book titles in descending order         
            while (j <= 0 && BookTitles[j].compareTo(key)<0) {
                BookTitles[j + 1] = BookTitles[j];
                j = j - 1;
            }
            BookTitles[j + 1] = key;
        }
       
    }
    
        
    
 
    public static void main(String[] args) {
     String[] BookTitles = {"The Great Gatsby", "Pride and Prejudice", "Othello","Harry Potter","To kill a mocking bird"};
String input = JOptionPane.showInputDialog("Enter a for ascending order and d for descending order. CASE SENSITIVE!");
if ( "a".equals(input))  {
   System.out.println("Layout of original array:");
        System.out.println(Arrays.toString(BookTitles));
        InsertionSort(BookTitles);
        System.out.println("This is the array after being sorted array:");
        System.out.println(Arrays.toString(BookTitles)); 
}  else {
       System.out.println("Layout of original array:");
        System.out.println(Arrays.toString(BookTitles));
        InsertionSortDec(BookTitles);
        System.out.println("This is the array after being sorted array:");
        System.out.println(Arrays.toString(BookTitles));
        

        
}
     
    }
    }
    

